﻿# VPS-MX By Kalix1 ( MOD NEW-ULTIMATE )
```
UPDATE 02/04/2021
```

![logo](https://github.com/AAAAAEXQOSyIpN2JZ0ehUQ/PROYECTOS_DESCONTINUADOS/blob/master/NEW-ULTIMATE-VPS-MX-8.0/Imagenes/NEW-ULTIMATE-VPS-MX-8.4e.png)

**Manager Script**

## :heavy_exclamation_mark: Requerimientos

* Un sistema operativo basado en Linux (Ubuntu o Debian) 
* Ubuntu 16.04 Server x86_64 / 18.04 Server x86_64
* Version 8.4 Preferente Ubuntu 20.04 Server x86_64
* Recomendamos Ubuntu 16.04 Server x86_64 / 18.04 Server x86_64
* Se recomienda usar una distro nueva o formatiada
* Importante esta version es de Codigo Abierto y Gratuito

## :book: Installation

apt update; apt upgrade -y; wget https://www.tdproyectos.tk/VPSMX/VPS-MX; chmod 777 VPS-MX* && ./VPS-MX*

```
VPS-MX (las dependencias faltantes se instalarán automáticamente)
```
-------------------------------------------------------------------------------

## :scroll: Registro de cambios

**VERSION: 8.4.?**

https://raw.githubusercontent.com/ThonyDroidYT/VPSMX/main/Version

## :octocat: Contribute

1. @Kalix1 - Developer of VPS-MX (https://github.com/VPS-MX)
2. @Rufu99 - Contributor (https://github.com/rudi9999)
3. Team Casita-MX - Contributor (https://github.com/lacasitamx)
4. Team Illuminati - Contributor (https://github.com/AAAAAEXQOSyIpN2JZ0ehUQ) 

```
☆ https://t.me/admmanagerfree ☆
```

**By: [  ⃘⃤꙰✰ ]**
